package tests

type Struct struct {
	Test string
}
