/*
Package esutil provides helper utilities to the Go client for Elasticsearch.

*/
package esutil
